// This file is created by egg-ts-helper@1.25.9
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportClient = require('../../../app/controller/client');
import ExportHome = require('../../../app/controller/home');
import ExportQrcode = require('../../../app/controller/qrcode');

declare module 'egg' {
  interface IController {
    client: ExportClient;
    home: ExportHome;
    qrcode: ExportQrcode;
  }
}
