'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  // 应用启动前回调函数
  // app.beforeStart(async () => {
  //   // 如果表不存在就创建
  //   await app.model.sync({ alter: false })
  // })

  // 测试 MQTT
  app.emqtt.get('uav').route('/test/#', app.mqtt.controller.test.index)

  // 测试二维码识别
  // 生成二维码
  router.get('/qrcode', controller.qrcode.index)
  // 识别二维码
  router.get('/getCode', controller.qrcode.getCode)

  // 电压
  router.post('/addAmaterList', controller.client.addAmaterList)
  router.get('/getAmaterList', controller.client.getAmaterList)

  // 电流
  router.post('/addFluentList', controller.client.addFluentList)
  router.get('/getFluentList', controller.client.getFluentList)

  // 测试
  router.get('/test', controller.client.test)
}
